from game import start_game

start_game()